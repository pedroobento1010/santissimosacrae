/**
 * Home — Paróquia Santíssimo Sacramento
 * Design: Herança Viva
 * Seções: Hero (fachada + brasão), Avisos, Padres, Serviços, Horários, Contato, Mapa
 */
import { Link } from "wouter";
import { MapPin, Phone, Mail, Clock, ChevronRight, Bell } from "lucide-react";

const FACHADA_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663523872742/6aNeGf63hbAocTazBTNR7V/fachada_77b4d7f8.jpg";
const OSTENSORIO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663523872742/6aNeGf63hbAocTazBTNR7V/ostensorio_e9738a28.png";
const PADRE1_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663523872742/6aNeGf63hbAocTazBTNR7V/padre1_f76b3761.jpg";
const PADRE2_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663523872742/6aNeGf63hbAocTazBTNR7V/padre2_e32d51d4.jpg";

const AVISOS = [
  {
    id: 1,
    tag: "Adoração",
    titulo: "Adoração Perpétua — 20 anos ininterruptos",
    texto: "Em 23 de outubro de 2025, o Santuário completou 20 anos de Adoração Perpétua ininterrupta. Venha adorar a Jesus Eucarístico!",
    data: "Contínua — 24h por dia",
  },
  {
    id: 2,
    tag: "Pastoral",
    titulo: "Escala de Adoradores",
    texto: "Paróquias, pastorais e movimentos assumem turnos mensais para garantir a continuidade da adoração. Inscreva-se na secretaria.",
    data: "Secretaria: Seg–Sex 8h–17h30",
  },
  {
    id: 3,
    tag: "Sacramentos",
    titulo: "Confissões disponíveis",
    texto: "Confissões: Terça a Sexta das 9h às 11h e das 15h às 16h30, além de 30 minutos antes de cada missa.",
    data: "Terça a Sexta",
  },
];

const SERVICOS = [
  {
    icon: "✝️",
    titulo: "Missas",
    descricao: "Celebrações eucarísticas diárias com acolhida e participação ativa dos fiéis.",
  },
  {
    icon: "🙏",
    titulo: "Confissões",
    descricao: "Sacramento da Reconciliação disponível em horários regulares e antes das missas.",
  },
  {
    icon: "💒",
    titulo: "Batismos",
    descricao: "Preparação e celebração do sacramento do Batismo para crianças e adultos.",
  },
  {
    icon: "💍",
    titulo: "Casamentos",
    descricao: "Acompanhamento pastoral e celebração do sacramento do Matrimônio.",
  },
  {
    icon: "📖",
    titulo: "Catequese",
    descricao: "Formação catequética para crianças, jovens e adultos em processo de iniciação cristã.",
  },
  {
    icon: "🕯️",
    titulo: "Adoração Perpétua",
    descricao: "Adoração ao Santíssimo Sacramento 24 horas por dia, todos os dias do ano.",
  },
  {
    icon: "🏥",
    titulo: "Pastoral da Saúde",
    descricao: "Visitas e assistência espiritual a enfermos e idosos em hospitais e residências.",
  },
  {
    icon: "📋",
    titulo: "Secretaria Paroquial",
    descricao: "Emissão de certidões, agendamentos e atendimento administrativo.",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* ── HERO ── */}
      <section className="relative min-h-[92vh] flex items-end" style={{ paddingTop: "4rem" }}>
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${FACHADA_URL})` }}
        />
        {/* Overlay gradiente */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to top, rgba(30,58,95,0.92) 0%, rgba(30,58,95,0.65) 45%, rgba(30,58,95,0.25) 100%)",
          }}
        />

        {/* Conteúdo */}
        <div className="relative z-10 container pb-16 md:pb-20">
          <div className="flex flex-col items-start gap-6 max-w-3xl">
            {/* Brasão / Ostensório */}
            <div className="flex items-center gap-5">
              <div
                className="w-20 h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center flex-shrink-0"
                style={{
                  background: "rgba(255,255,255,0.12)",
                  backdropFilter: "blur(8px)",
                  border: "2px solid rgba(212,160,23,0.5)",
                  boxShadow: "0 0 40px rgba(212,160,23,0.2)",
                }}
              >
                <img
                  src={OSTENSORIO_URL}
                  alt="Ostensório — Santíssimo Sacramento"
                  className="w-14 h-14 md:w-16 md:h-16 object-contain drop-shadow-lg"
                />
              </div>
              <div>
                <p className="text-blue-200 text-xs md:text-sm font-semibold uppercase tracking-widest">
                  Santuário Arquidiocesano
                </p>
                <p className="text-blue-300 text-xs">da Adoração Perpétua — Brasília, DF</p>
              </div>
            </div>

            {/* Linha dourada */}
            <div style={{ width: "4rem", height: "3px", background: "linear-gradient(90deg, #b8860b, #d4a017)", borderRadius: "2px" }} />

            {/* Título */}
            <div>
              <h1
                className="text-white text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4"
                style={{ fontFamily: "Merriweather, serif", textShadow: "0 2px 20px rgba(0,0,0,0.4)" }}
              >
                Paróquia<br />
                Santíssimo<br />
                <span style={{ color: "#d4a017" }}>Sacramento</span>
              </h1>
              <p className="text-blue-100 text-base md:text-lg max-w-xl leading-relaxed">
                Adoração Perpétua ininterrupta desde 2005 — um pilar da espiritualidade eucarística em Brasília.
              </p>
              <div className="flex flex-wrap gap-3 mt-6">
                <Link
                  href="/sobre"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all duration-200 hover:opacity-90"
                  style={{ background: "#d4a017", color: "#1e3a5f" }}
                >
                  Conheça nossa história <ChevronRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/contato"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm border border-white/40 text-white hover:bg-white/15 transition-all duration-200"
                >
                  Fale conosco
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-white/40 flex items-start justify-center pt-2">
            <div className="w-1.5 h-3 rounded-full bg-white/60" />
          </div>
        </div>
      </section>

      {/* ── QUADRO DE AVISOS ── */}
      <section className="py-16" style={{ background: "#dbeafe" }}>
        <div className="container">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <Bell className="w-5 h-5" style={{ color: "#1e3a5f" }} />
              <h2 className="section-title section-title-center text-2xl md:text-3xl">
                Quadro de Avisos
              </h2>
            </div>
            <div className="gold-divider" />
            <p className="text-gray-600 mt-3 max-w-xl mx-auto">
              Fique por dentro das novidades e eventos da nossa comunidade paroquial.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {AVISOS.map((aviso) => (
              <div key={aviso.id} className="parish-card p-6">
                <span
                  className="inline-block text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full mb-3"
                  style={{ background: "#bfdbfe", color: "#1e3a5f" }}
                >
                  {aviso.tag}
                </span>
                <h3
                  className="font-bold text-base mb-2 leading-snug"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  {aviso.titulo}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-3">{aviso.texto}</p>
                <p className="text-xs font-semibold" style={{ color: "#b8860b" }}>
                  📅 {aviso.data}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── NOSSOS PADRES ── */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="section-title section-title-center text-2xl md:text-3xl">
              Nossa Equipe Pastoral
            </h2>
            <div className="gold-divider" />
            <p className="text-gray-600 mt-3">
              Conheça os sacerdotes que servem nossa comunidade.
            </p>
          </div>

          <div className="flex flex-col md:flex-row gap-8 justify-center max-w-3xl mx-auto">
            {/* Pároco */}
            <div className="parish-card p-8 flex flex-col items-center text-center flex-1">
              <div
                className="w-28 h-28 rounded-full overflow-hidden mb-4"
                style={{ boxShadow: "0 0 0 4px #bfdbfe" }}
              >
                <img
                  src={PADRE1_URL}
                  alt="Padre Wilson José Santos Pereira"
                  className="w-full h-full object-cover"
                />
              </div>
              <span
                className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full mb-3"
                style={{ background: "#1e3a5f", color: "white" }}
              >
                Pároco
              </span>
              <h3
                className="font-bold text-lg mb-1"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Pe. Wilson José Santos Pereira
              </h3>
              <div className="gold-divider" style={{ margin: "0.5rem auto" }} />
              <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                Pároco e Reitor do Santuário Arquidiocesano da Adoração Perpétua. Responsável pela coordenação pastoral e espiritual da comunidade.
              </p>
            </div>

            {/* Vigário */}
            <div className="parish-card p-8 flex flex-col items-center text-center flex-1">
              <div
                className="w-28 h-28 rounded-full overflow-hidden mb-4"
                style={{ boxShadow: "0 0 0 4px #bfdbfe" }}
              >
                <img
                  src={PADRE2_URL}
                  alt="Padre Lázaro Ilzo Daniel"
                  className="w-full h-full object-cover"
                />
              </div>
              <span
                className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full mb-3"
                style={{ background: "#2563eb", color: "white" }}
              >
                Vigário
              </span>
              <h3
                className="font-bold text-lg mb-1"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Pe. Lázaro Ilzo Daniel
              </h3>
              <div className="gold-divider" style={{ margin: "0.5rem auto" }} />
              <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                Vigário paroquial, auxiliando nas celebrações, atendimento pastoral e acompanhamento espiritual dos fiéis da comunidade.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── SERVIÇOS ── */}
      <section className="py-16" style={{ background: "#f0f7ff" }}>
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="section-title section-title-center text-2xl md:text-3xl">
              Serviços Paroquiais
            </h2>
            <div className="gold-divider" />
            <p className="text-gray-600 mt-3 max-w-xl mx-auto">
              A Paróquia Santíssimo Sacramento oferece uma ampla gama de serviços pastorais e sacramentais para toda a comunidade.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {SERVICOS.map((servico) => (
              <div
                key={servico.titulo}
                className="bg-white rounded-xl p-6 text-center transition-all duration-200 hover:-translate-y-1"
                style={{
                  boxShadow: "0 2px 12px rgba(30,58,95,0.07)",
                  borderBottom: "3px solid #bfdbfe",
                }}
              >
                <div className="text-3xl mb-3">{servico.icon}</div>
                <h3
                  className="font-bold text-base mb-2"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  {servico.titulo}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed">{servico.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HORÁRIOS ── */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="section-title section-title-center text-2xl md:text-3xl">
              Horários
            </h2>
            <div className="gold-divider" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {/* Missas */}
            <div className="parish-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: "#dbeafe" }}
                >
                  <span className="text-lg">✝️</span>
                </div>
                <h3
                  className="font-bold text-base"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  Horários de Missa
                </h3>
              </div>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex justify-between items-center py-1.5 border-b border-blue-50">
                  <span className="font-medium">Segunda a Sábado</span>
                  <span className="font-bold text-blue-700">7h30 e 19h</span>
                </li>
                <li className="flex justify-between items-center py-1.5">
                  <span className="font-medium">Domingo</span>
                  <span className="font-bold text-blue-700">10h e 19h</span>
                </li>
              </ul>
            </div>

            {/* Confissões */}
            <div className="parish-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: "#dbeafe" }}
                >
                  <span className="text-lg">🙏</span>
                </div>
                <h3
                  className="font-bold text-base"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  Confissões
                </h3>
              </div>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex justify-between items-center py-1.5 border-b border-blue-50">
                  <span className="font-medium">Terça e Quinta</span>
                  <span className="font-bold text-blue-700">9h–11h</span>
                </li>
                <li className="flex justify-between items-center py-1.5 border-b border-blue-50">
                  <span className="font-medium">Terça a Sexta</span>
                  <span className="font-bold text-blue-700">15h–16h30</span>
                </li>
                <li className="py-1.5 text-xs text-gray-500 italic">
                  Também 30 min antes das missas
                </li>
              </ul>
            </div>

            {/* Secretaria */}
            <div className="parish-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: "#dbeafe" }}
                >
                  <Clock className="w-5 h-5 text-blue-700" />
                </div>
                <h3
                  className="font-bold text-base"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  Secretaria
                </h3>
              </div>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex justify-between items-center py-1.5 border-b border-blue-50">
                  <span className="font-medium">Seg–Sex</span>
                  <span className="font-bold text-blue-700">8h–12h / 13h–17h30</span>
                </li>
                <li className="flex justify-between items-center py-1.5">
                  <span className="font-medium">Sábado</span>
                  <span className="font-bold text-blue-700">8h–12h</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ── CONTATO ── */}
      <section className="py-16" style={{ background: "#1e3a5f" }}>
        <div className="container">
          <div className="text-center mb-10">
            <h2
              className="text-2xl md:text-3xl font-bold text-white mb-2"
              style={{ fontFamily: "Merriweather, serif" }}
            >
              Entre em Contato
            </h2>
            <div className="gold-divider" />
            <p className="text-blue-200 mt-3">
              Estamos aqui para servir. Fale conosco pelos canais abaixo.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                icon: <MapPin className="w-6 h-6" />,
                titulo: "Endereço",
                linha1: "SGAS 606 Lotes 41/42 — L2 Sul",
                linha2: "Asa Sul, 70.200-660, Brasília — DF",
                href: "/localizacao",
                linkLabel: "Ver no mapa",
              },
              {
                icon: <Phone className="w-6 h-6" />,
                titulo: "Telefone / WhatsApp",
                linha1: "(61) 3443-8909",
                linha2: "WhatsApp disponível",
                href: "https://wa.me/556134438909",
                linkLabel: "Chamar no WhatsApp",
              },
              {
                icon: <Mail className="w-6 h-6" />,
                titulo: "E-mail",
                linha1: "secretaria.santissimo",
                linha2: "@gmail.com",
                href: "mailto:secretaria.santissimo@gmail.com",
                linkLabel: "Enviar e-mail",
              },
            ].map((item) => (
              <div
                key={item.titulo}
                className="rounded-xl p-6 text-center"
                style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)" }}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-white"
                  style={{ background: "rgba(212,160,23,0.25)" }}
                >
                  {item.icon}
                </div>
                <h3
                  className="font-bold text-white mb-2"
                  style={{ fontFamily: "Merriweather, serif" }}
                >
                  {item.titulo}
                </h3>
                <p className="text-blue-200 text-sm">{item.linha1}</p>
                <p className="text-blue-200 text-sm mb-3">{item.linha2}</p>
                <a
                  href={item.href}
                  className="text-xs font-bold uppercase tracking-wider transition-colors hover:opacity-80"
                  style={{ color: "#d4a017" }}
                  target={item.href.startsWith("http") ? "_blank" : undefined}
                  rel={item.href.startsWith("http") ? "noopener noreferrer" : undefined}
                >
                  {item.linkLabel} →
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── MAPA ── */}
      <section className="py-0">
        <div className="w-full" style={{ height: "400px" }}>
          <Link href="/localizacao" className="block w-full h-full">
            <iframe
              title="Localização da Paróquia Santíssimo Sacramento"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3838.8!2d-47.9194!3d-15.8235!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x935a2b8b3c8a3a3b%3A0x5e8e8e8e8e8e8e8e!2sSGAS%20606%20-%20Asa%20Sul%2C%20Bras%C3%ADlia%20-%20DF%2C%2070200-660!5e0!3m2!1spt-BR!2sbr!4v1700000000000!5m2!1spt-BR!2sbr"
              width="100%"
              height="400"
              style={{ border: 0, display: "block" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </Link>
        </div>
        <div
          className="text-center py-3 text-sm font-semibold"
          style={{ background: "#1e3a5f", color: "#bfdbfe" }}
        >
          <Link href="/localizacao" className="hover:text-white transition-colors">
            📍 SGAS 606 Lotes 41/42 — L2 Sul, Asa Sul, Brasília DF — Clique para ver detalhes da localização →
          </Link>
        </div>
      </section>
    </div>
  );
}
