/**
 * Localização — Paróquia Santíssimo Sacramento
 * Design: Herança Viva — mapa Google Maps integrado, informações de acesso
 */
import { Link } from "wouter";
import { ChevronRight, MapPin, Car, Bus, Clock, Phone } from "lucide-react";
import { MapView } from "@/components/Map";
import { useCallback, useRef } from "react";

export default function Localizacao() {
  const mapRef = useRef<google.maps.Map | null>(null);

  const handleMapReady = useCallback((map: google.maps.Map) => {
    mapRef.current = map;

    const position = { lat: -15.8235, lng: -47.9194 };
    map.setCenter(position);
    map.setZoom(17);

    const marker = new google.maps.marker.AdvancedMarkerElement({
      position,
      map,
      title: "Paróquia Santíssimo Sacramento",
    });

    const infoWindow = new google.maps.InfoWindow({
      content: `
        <div style="font-family: 'Source Sans 3', sans-serif; max-width: 220px; padding: 4px;">
          <strong style="color: #1e3a5f; font-size: 14px; display: block; margin-bottom: 4px;">
            Paróquia Santíssimo Sacramento
          </strong>
          <p style="color: #555; font-size: 12px; margin: 0; line-height: 1.5;">
            SGAS 606 Lotes 41/42 — L2 Sul<br/>
            Asa Sul, 70.200-660<br/>
            Brasília — DF
          </p>
          <a href="https://maps.google.com/?q=SGAS+606+L2+Sul+Asa+Sul+Brasilia+DF" 
             target="_blank" 
             style="color: #2563eb; font-size: 12px; text-decoration: none; font-weight: 600; display: block; margin-top: 6px;">
            Abrir no Google Maps →
          </a>
        </div>
      `,
    });

    marker.addListener("click", () => {
      infoWindow.open({ map, anchor: marker as unknown as google.maps.MVCObject });
    });

    // Abrir info window automaticamente
    infoWindow.open({ map, anchor: marker as unknown as google.maps.MVCObject });
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      {/* ── HERO ── */}
      <section
        className="relative flex items-end"
        style={{
          paddingTop: "4rem",
          minHeight: "35vh",
          background: "linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%)",
        }}
      >
        <div className="relative z-10 container pb-10">
          <nav className="flex items-center gap-2 text-blue-200 text-sm mb-4">
            <Link href="/" className="hover:text-white transition-colors">Início</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-white">Localização</span>
          </nav>
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(255,255,255,0.15)" }}
            >
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1
                className="text-white text-3xl md:text-4xl font-bold leading-tight"
                style={{ fontFamily: "Merriweather, serif" }}
              >
                Como Chegar
              </h1>
              <p className="text-blue-200 mt-1">
                SGAS 606 Lotes 41/42 — L2 Sul, Asa Sul, Brasília — DF
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── MAPA INTERATIVO ── */}
      <section className="bg-white">
        <div
          className="w-full"
          style={{ height: "500px" }}
        >
          <MapView onMapReady={handleMapReady} />
        </div>
        <div className="text-center py-3 text-sm" style={{ background: "#f0f7ff" }}>
          <a
            href="https://maps.google.com/?q=SGAS+606+L2+Sul+Asa+Sul+Brasilia+DF"
            target="_blank"
            rel="noopener noreferrer"
            className="font-semibold transition-colors hover:opacity-80"
            style={{ color: "#1e3a5f" }}
          >
            📍 Abrir no Google Maps →
          </a>
        </div>
      </section>

      {/* ── INFORMAÇÕES DE ACESSO ── */}
      <section className="py-16" style={{ background: "#dbeafe" }}>
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="section-title section-title-center text-2xl md:text-3xl">
              Informações de Acesso
            </h2>
            <div className="gold-divider" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 max-w-5xl mx-auto">
            {/* Endereço */}
            <div className="parish-card p-6 text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: "#dbeafe" }}
              >
                <MapPin className="w-6 h-6" style={{ color: "#1e3a5f" }} />
              </div>
              <h3
                className="font-bold mb-2"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Endereço
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                SGAS 606 Lotes 41/42<br />
                L2 Sul — Asa Sul<br />
                CEP: 70.200-660<br />
                Brasília — DF
              </p>
            </div>

            {/* De carro */}
            <div className="parish-card p-6 text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: "#dbeafe" }}
              >
                <Car className="w-6 h-6" style={{ color: "#1e3a5f" }} />
              </div>
              <h3
                className="font-bold mb-2"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                De Carro
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Acesso pela L2 Sul, entre as quadras 605 e 607. Estacionamento disponível na área frontal da igreja.
              </p>
            </div>

            {/* De ônibus */}
            <div className="parish-card p-6 text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: "#dbeafe" }}
              >
                <Bus className="w-6 h-6" style={{ color: "#1e3a5f" }} />
              </div>
              <h3
                className="font-bold mb-2"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Transporte Público
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Diversas linhas de ônibus passam pela W3 Sul e L2 Sul. Consulte o DFTrans para rotas disponíveis.
              </p>
            </div>

            {/* Horários */}
            <div className="parish-card p-6 text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: "#dbeafe" }}
              >
                <Clock className="w-6 h-6" style={{ color: "#1e3a5f" }} />
              </div>
              <h3
                className="font-bold mb-2"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Funcionamento
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Igreja aberta todos os dias para adoração. Secretaria: Seg–Sex 8h–17h30 | Sáb 8h–12h.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── CONTATO RÁPIDO ── */}
      <section className="py-12 bg-white">
        <div className="container">
          <div
            className="max-w-2xl mx-auto rounded-2xl p-8 text-center"
            style={{ background: "#1e3a5f" }}
          >
            <h3
              className="text-white font-bold text-xl mb-3"
              style={{ fontFamily: "Merriweather, serif" }}
            >
              Precisa de mais informações?
            </h3>
            <p className="text-blue-200 mb-5 text-sm">
              Entre em contato com a secretaria paroquial.
            </p>
            <div className="flex flex-wrap gap-3 justify-center">
              <a
                href="tel:+556134438909"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm text-white transition-all duration-200 hover:opacity-90"
                style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)" }}
              >
                <Phone className="w-4 h-4" />
                (61) 3443-8909
              </a>
              <a
                href="https://wa.me/556134438909"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all duration-200 hover:opacity-90"
                style={{ background: "#d4a017", color: "#1e3a5f" }}
              >
                WhatsApp →
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
