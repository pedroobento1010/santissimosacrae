/**
 * Sobre — Paróquia Santíssimo Sacramento
 * Design: Herança Viva — página separada com texto histórico completo
 */
import { Link } from "wouter";
import { ChevronRight } from "lucide-react";

const FACHADA2_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663523872742/6aNeGf63hbAocTazBTNR7V/fachada2_b8452c3e.jpg";
const OSTENSORIO2_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663523872742/6aNeGf63hbAocTazBTNR7V/ostensorio2_d554957c.png";

export default function Sobre() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* ── HERO DA PÁGINA SOBRE ── */}
      <section
        className="relative flex items-end"
        style={{ paddingTop: "4rem", minHeight: "50vh" }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${FACHADA2_URL})` }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to top, rgba(30,58,95,0.95) 0%, rgba(30,58,95,0.6) 60%, rgba(30,58,95,0.2) 100%)",
          }}
        />
        <div className="relative z-10 container pb-14">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-blue-200 text-sm mb-4">
            <Link href="/" className="hover:text-white transition-colors">Início</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-white">Sobre</span>
          </nav>
          <h1
            className="text-white text-3xl md:text-5xl font-bold leading-tight mb-3"
            style={{ fontFamily: "Merriweather, serif", textShadow: "0 2px 20px rgba(0,0,0,0.4)" }}
          >
            Sobre a Paróquia
          </h1>
          <p className="text-blue-200 text-lg max-w-2xl">
            Conheça a história e o legado do Santuário Arquidiocesano da Adoração Perpétua em Brasília.
          </p>
        </div>
      </section>

      {/* ── CONTEÚDO PRINCIPAL ── */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="max-w-4xl mx-auto">

            {/* Intro com ostensório */}
            <div className="flex flex-col md:flex-row gap-10 items-center mb-14">
              <div className="flex-shrink-0 flex justify-center">
                <div
                  className="w-40 h-40 rounded-full flex items-center justify-center"
                  style={{
                    background: "#dbeafe",
                    boxShadow: "0 0 0 6px #bfdbfe",
                  }}
                >
                  <img
                    src={OSTENSORIO2_URL}
                    alt="Ostensório Santíssimo Sacramento"
                    className="w-28 h-28 object-contain"
                  />
                </div>
              </div>
              <div>
                <h2
                  className="section-title text-2xl md:text-3xl mb-4"
                  style={{ fontFamily: "Merriweather, serif" }}
                >
                  História e Idealização
                </h2>
                <div className="gold-divider" style={{ margin: "0 0 1rem 0" }} />
                <p className="text-gray-600 leading-relaxed text-base">
                  A trajetória do Santuário Arquidiocesano da Adoração Perpétua, em Brasília, é marcada por um crescimento gradual e pela consolidação da devoção eucarística na capital. Desde sua fundação, a comunidade se tornou um pilar da espiritualidade católica no Distrito Federal.
                </p>
              </div>
            </div>

            {/* Linha do tempo / Seções */}
            <div className="space-y-10">

              {/* Seção 1 */}
              <div
                className="rounded-xl overflow-hidden"
                style={{ border: "1px solid #dbeafe" }}
              >
                <div
                  className="px-6 py-4"
                  style={{ background: "#1e3a5f" }}
                >
                  <h3
                    className="text-white font-bold text-xl"
                    style={{ fontFamily: "Merriweather, serif" }}
                  >
                    As Primeiras Edificações e a Visão Eucarística
                  </h3>
                </div>
                <div className="p-6 bg-white">
                  <div className="space-y-4 text-gray-600 leading-relaxed">
                    <p>
                      A história da comunidade teve início em <strong>25 de março de 1960</strong>, com a inauguração da <em>Capela-Matriz de Nossa Senhora do Santíssimo Sacramento</em> na quadra 402 Sul. Esta capela pertencia à Congregação do Santíssimo Sacramento (Padres Sacramentinos), que já vislumbrava um futuro Santuário da Adoração Perpétua.
                    </p>
                    <p>
                      Em <strong>1º de setembro de 1966</strong>, foi acertada a mudança dos Padres Sacramentinos para um terreno mais promissor em frente às quadras 405–406, na L2 Sul, visando o desenvolvimento da Obra Eucarística. A construção da nova capela do Santíssimo Sacramento foi iniciada em <strong>8 de maio de 1967</strong>, na quadra 606 Sul (L2 Sul).
                    </p>
                    <p>
                      O <em>"novo-salão-Capela"</em> foi inaugurado em <strong>29 de outubro de 1967</strong>, na festa de Cristo Rei. Durante a homilia dessa solenidade, Dom José Newton de Almeida Baptista, Arcebispo de Brasília, expressou o desejo de que Brasília possuísse a obra de São Pedro Julião Eymard, reforçando a vocação eucarística do local.
                    </p>
                    <p>
                      Em <strong>13 de abril de 1969</strong>, a Paróquia passou a pertencer ao Clero Secular, e a construção da atual igreja principal teve sua pedra fundamental lançada em <strong>8 de outubro de 1972</strong>. A nova Igreja do Santíssimo Sacramento foi finalmente inaugurada em <strong>5 de dezembro de 1982</strong>.
                    </p>
                  </div>
                </div>
              </div>

              {/* Seção 2 */}
              <div
                className="rounded-xl overflow-hidden"
                style={{ border: "1px solid #dbeafe" }}
              >
                <div
                  className="px-6 py-4"
                  style={{ background: "#2563eb" }}
                >
                  <h3
                    className="text-white font-bold text-xl"
                    style={{ fontFamily: "Merriweather, serif" }}
                  >
                    O Estabelecimento da Adoração Perpétua
                  </h3>
                </div>
                <div className="p-6 bg-white">
                  <div className="space-y-4 text-gray-600 leading-relaxed">
                    <p>
                      A ideia da Adoração Perpétua no local não foi imediata. Houve tentativas anteriores de adoração contínua na Arquidiocese, como em uma pequena sala do Santuário Dom Bosco (1994–1999) e, depois, em <strong>5 de janeiro de 2001</strong>, Dom José Freire Falcão decretou que a Capela do Santuário Dom Bosco sediaria, provisoriamente, a Adoração Perpétua.
                    </p>
                    <p>
                      Inicialmente, ela funcionou 24 horas por dia até janeiro de 2003. No mês seguinte, em fevereiro de 2003, o horário foi reduzido, com o encerramento das atividades às 22h, e a adoração noturna passou a ser realizada em capelas de comunidades religiosas.
                    </p>
                    <p>
                      O marco definitivo ocorreu em <strong>2005, Ano da Eucaristia</strong>. Dom João Braz de Aviz reinstaurou formalmente a Adoração Perpétua na então Paróquia do Santíssimo Sacramento em <strong>23 de outubro de 2005</strong>, com uma missa solene de inauguração.
                    </p>
                    <p>
                      Menos de um ano depois, em <strong>15 de julho de 2006</strong>, na solenidade de Corpus Christi, o arcebispo assinou o <em>Decreto Protocolo nº 11/2006</em>, criando o <strong>Santuário Arquidiocesano da Adoração Perpétua a Jesus Cristo no Santíssimo Sacramento da Eucaristia</strong>. Na mesma ocasião, o então pároco, Padre Adriano Scarparo, recebeu o título de reitor do santuário.
                    </p>
                  </div>
                </div>
              </div>

              {/* Seção 3 */}
              <div
                className="rounded-xl overflow-hidden"
                style={{ border: "1px solid #dbeafe" }}
              >
                <div
                  className="px-6 py-4"
                  style={{ background: "#b8860b" }}
                >
                  <h3
                    className="text-white font-bold text-xl"
                    style={{ fontFamily: "Merriweather, serif" }}
                  >
                    Legado e Compromisso Contínuo
                  </h3>
                </div>
                <div className="p-6 bg-white">
                  <div className="space-y-4 text-gray-600 leading-relaxed">
                    <p>
                      Desde sua criação, o Santuário assumiu um papel central na vida eucarística da arquidiocese, tornando-se uma referência de adoração contínua e um espaço vital para a formação espiritual dos fiéis. Em <strong>23 de outubro de 2025</strong>, o Santuário completou <strong>20 anos de Adoração Perpétua ininterrupta</strong>.
                    </p>
                    <p>
                      A manutenção da adoração 24 horas por dia é garantida por uma escala de adoradores, organizada pela <em>Comissão Arquidiocesana da Adoração Perpétua (CAAEP)</em>, criada em 2016 sob a orientação do então bispo auxiliar Dom Marcony Vinícius Ferreira e do Padre Wilson Pereira, reitor do Santuário. Paróquias, pastorais, movimentos e serviços assumem turnos mensais para assegurar a continuidade.
                    </p>
                    <p>
                      Dessa forma, a Adoração Perpétua no Santuário do Santíssimo Sacramento é um testemunho vivo da fé católica, fortalecendo a espiritualidade e o compromisso dos fiéis diante do Senhor, tornando-o um pilar da comunidade arquidiocesana.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div
              className="mt-12 rounded-xl p-8 text-center"
              style={{ background: "#dbeafe" }}
            >
              <h3
                className="font-bold text-xl mb-3"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Venha nos visitar
              </h3>
              <p className="text-gray-600 mb-5">
                A Adoração Perpétua está aberta 24 horas por dia. Venha adorar a Jesus Eucarístico e fazer parte desta comunidade.
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                <Link
                  href="/localizacao"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm text-white transition-all duration-200 hover:opacity-90"
                  style={{ background: "#1e3a5f" }}
                >
                  Ver localização <ChevronRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/contato"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all duration-200 hover:opacity-90"
                  style={{ background: "#b8860b", color: "white" }}
                >
                  Fale conosco <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}
