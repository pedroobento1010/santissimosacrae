/**
 * Contato — Paróquia Santíssimo Sacramento
 * Design: Herança Viva — informações completas de contato
 */
import { Link } from "wouter";
import { ChevronRight, MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";

export default function Contato() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* ── HERO ── */}
      <section
        className="relative flex items-end"
        style={{
          paddingTop: "4rem",
          minHeight: "35vh",
          background: "linear-gradient(135deg, #1e3a5f 0%, #1d4ed8 100%)",
        }}
      >
        <div className="relative z-10 container pb-10">
          <nav className="flex items-center gap-2 text-blue-200 text-sm mb-4">
            <Link href="/" className="hover:text-white transition-colors">Início</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-white">Contate-nos</span>
          </nav>
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(255,255,255,0.15)" }}
            >
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1
                className="text-white text-3xl md:text-4xl font-bold leading-tight"
                style={{ fontFamily: "Merriweather, serif" }}
              >
                Contate-nos
              </h1>
              <p className="text-blue-200 mt-1">
                Estamos aqui para servir. Entre em contato conosco.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── INFORMAÇÕES DE CONTATO ── */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">

              {/* Endereço */}
              <div className="parish-card p-7">
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: "#dbeafe" }}
                  >
                    <MapPin className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                  </div>
                  <div>
                    <h3
                      className="font-bold text-lg mb-2"
                      style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                    >
                      Endereço
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      SGAS 606 Lotes 41/42 — L2 Sul<br />
                      Asa Sul, CEP: 70.200-660<br />
                      Brasília — DF
                    </p>
                    <Link
                      href="/localizacao"
                      className="inline-block mt-3 text-sm font-semibold transition-colors hover:opacity-80"
                      style={{ color: "#2563eb" }}
                    >
                      Ver no mapa →
                    </Link>
                  </div>
                </div>
              </div>

              {/* Telefone e WhatsApp */}
              <div className="parish-card p-7">
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: "#dbeafe" }}
                  >
                    <Phone className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                  </div>
                  <div>
                    <h3
                      className="font-bold text-lg mb-2"
                      style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                    >
                      Telefone / WhatsApp
                    </h3>
                    <p className="text-gray-600 mb-2">
                      <a
                        href="tel:+556134438909"
                        className="font-semibold hover:underline"
                        style={{ color: "#1e3a5f" }}
                      >
                        (61) 3443-8909
                      </a>
                    </p>
                    <a
                      href="https://wa.me/556134438909"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all duration-200 hover:opacity-90"
                      style={{ background: "#25D366" }}
                    >
                      <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                      Chamar no WhatsApp
                    </a>
                  </div>
                </div>
              </div>

              {/* E-mail */}
              <div className="parish-card p-7">
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: "#dbeafe" }}
                  >
                    <Mail className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                  </div>
                  <div>
                    <h3
                      className="font-bold text-lg mb-2"
                      style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                    >
                      E-mail
                    </h3>
                    <a
                      href="mailto:secretaria.santissimo@gmail.com"
                      className="font-semibold text-sm hover:underline break-all"
                      style={{ color: "#2563eb" }}
                    >
                      secretaria.santissimo@gmail.com
                    </a>
                    <p className="text-gray-500 text-sm mt-2">
                      Respondemos em até 2 dias úteis.
                    </p>
                  </div>
                </div>
              </div>

              {/* Horários */}
              <div className="parish-card p-7">
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: "#dbeafe" }}
                  >
                    <Clock className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                  </div>
                  <div>
                    <h3
                      className="font-bold text-lg mb-3"
                      style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                    >
                      Horários da Secretaria
                    </h3>
                    <table className="w-full text-sm">
                      <tbody>
                        <tr className="border-b border-blue-50">
                          <td className="py-1.5 font-medium text-gray-700 pr-4">Segunda a Sexta</td>
                          <td className="py-1.5 font-bold" style={{ color: "#1e3a5f" }}>8h–12h e 13h–17h30</td>
                        </tr>
                        <tr>
                          <td className="py-1.5 font-medium text-gray-700 pr-4">Sábado</td>
                          <td className="py-1.5 font-bold" style={{ color: "#1e3a5f" }}>8h–12h</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            {/* Horários de Missa e Confissões */}
            <div
              className="rounded-2xl overflow-hidden"
              style={{ border: "1px solid #dbeafe" }}
            >
              <div className="px-6 py-4" style={{ background: "#1e3a5f" }}>
                <h3
                  className="text-white font-bold text-xl"
                  style={{ fontFamily: "Merriweather, serif" }}
                >
                  Horários de Missas e Confissões
                </h3>
              </div>
              <div className="p-6 bg-white">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Missas */}
                  <div>
                    <h4
                      className="font-bold mb-4 flex items-center gap-2"
                      style={{ color: "#1e3a5f", fontFamily: "Merriweather, serif" }}
                    >
                      <span className="text-xl">✝️</span> Missas
                    </h4>
                    <table className="w-full text-sm">
                      <tbody>
                        <tr className="border-b border-blue-50">
                          <td className="py-2 font-medium text-gray-700 pr-4">Segunda a Sábado</td>
                          <td className="py-2 font-bold text-blue-700">7h30 e 19h</td>
                        </tr>
                        <tr>
                          <td className="py-2 font-medium text-gray-700 pr-4">Domingo</td>
                          <td className="py-2 font-bold text-blue-700">10h e 19h</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Confissões */}
                  <div>
                    <h4
                      className="font-bold mb-4 flex items-center gap-2"
                      style={{ color: "#1e3a5f", fontFamily: "Merriweather, serif" }}
                    >
                      <span className="text-xl">🙏</span> Confissões
                    </h4>
                    <table className="w-full text-sm">
                      <tbody>
                        <tr className="border-b border-blue-50">
                          <td className="py-2 font-medium text-gray-700 pr-4">Terça e Quinta</td>
                          <td className="py-2 font-bold text-blue-700">9h–11h</td>
                        </tr>
                        <tr className="border-b border-blue-50">
                          <td className="py-2 font-medium text-gray-700 pr-4">Terça a Sexta</td>
                          <td className="py-2 font-bold text-blue-700">15h–16h30</td>
                        </tr>
                        <tr>
                          <td className="py-2 text-gray-500 italic text-xs" colSpan={2}>
                            Também disponível 30 minutos antes de cada missa
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── MAPA RESUMIDO ── */}
      <section className="py-0">
        <div className="w-full" style={{ height: "300px" }}>
          <iframe
            title="Mapa da Paróquia"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3838.8!2d-47.9194!3d-15.8235!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x935a2b8b3c8a3a3b%3A0x5e8e8e8e8e8e8e8e!2sSGAS%20606%20-%20Asa%20Sul%2C%20Bras%C3%ADlia%20-%20DF%2C%2070200-660!5e0!3m2!1spt-BR!2sbr!4v1700000000000!5m2!1spt-BR!2sbr"
            width="100%"
            height="300"
            style={{ border: 0, display: "block" }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
        <div className="text-center py-3 text-sm" style={{ background: "#f0f7ff" }}>
          <Link href="/localizacao" className="font-semibold transition-colors hover:opacity-80" style={{ color: "#1e3a5f" }}>
            Ver mapa interativo completo →
          </Link>
        </div>
      </section>
    </div>
  );
}
