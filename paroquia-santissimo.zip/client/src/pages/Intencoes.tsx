/**
 * Intenções de Missa — Paróquia Santíssimo Sacramento
 * Design: Herança Viva — formulário Google Forms integrado para intenções semanais
 */
import { Link } from "wouter";
import { ChevronRight, Heart, Users, Flame } from "lucide-react";

export default function Intencoes() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* ── HERO ── */}
      <section
        className="relative flex items-end"
        style={{
          paddingTop: "4rem",
          minHeight: "35vh",
          background: "linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%)",
        }}
      >
        <div className="relative z-10 container pb-10">
          <nav className="flex items-center gap-2 text-blue-200 text-sm mb-4">
            <Link href="/" className="hover:text-white transition-colors">Início</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-white">Intenções de Missa</span>
          </nav>
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(255,255,255,0.15)" }}
            >
              <Flame className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1
                className="text-white text-3xl md:text-4xl font-bold leading-tight"
                style={{ fontFamily: "Merriweather, serif" }}
              >
                Intenções de Missa
              </h1>
              <p className="text-blue-200 mt-1">
                Registre suas intenções para as missas semanais
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── CONTEÚDO PRINCIPAL ── */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            {/* Introdução */}
            <div className="mb-12 text-center">
              <h2
                className="text-2xl md:text-3xl font-bold mb-4"
                style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
              >
                Ofereça uma Intenção para a Missa
              </h2>
              <div className="gold-divider" />
              <p className="text-gray-600 leading-relaxed max-w-2xl mx-auto">
                Você pode registrar intenções de missa para pessoas vivas ou falecidas. 
                Suas intenções serão lembradas durante as celebrações eucarísticas de nossa comunidade.
              </p>
            </div>

            {/* Grid de informações */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {/* Card 1 */}
              <div className="parish-card p-6 text-center">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                  style={{ background: "#dbeafe" }}
                >
                  <Heart className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                </div>
                <h3
                  className="font-bold mb-2"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  Por Pessoas Vivas
                </h3>
                <p className="text-gray-600 text-sm">
                  Ofereça uma missa por saúde, proteção, graças alcançadas ou intenções especiais.
                </p>
              </div>

              {/* Card 2 */}
              <div className="parish-card p-6 text-center">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                  style={{ background: "#dbeafe" }}
                >
                  <Users className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                </div>
                <h3
                  className="font-bold mb-2"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  Por Falecidos
                </h3>
                <p className="text-gray-600 text-sm">
                  Reze pela alma de pessoas falecidas, pedindo paz e descanso eterno.
                </p>
              </div>

              {/* Card 3 */}
              <div className="parish-card p-6 text-center">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                  style={{ background: "#dbeafe" }}
                >
                  <Flame className="w-6 h-6" style={{ color: "#1e3a5f" }} />
                </div>
                <h3
                  className="font-bold mb-2"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  Intenções Especiais
                </h3>
                <p className="text-gray-600 text-sm">
                  Ofereça uma missa por agradecimentos, conversões ou necessidades urgentes.
                </p>
              </div>
            </div>

            {/* Formulário Google Forms */}
            <div
              className="rounded-2xl overflow-hidden"
              style={{ border: "1px solid #dbeafe" }}
            >
              <div className="px-6 py-4" style={{ background: "#1e3a5f" }}>
                <h3
                  className="text-white font-bold text-lg"
                  style={{ fontFamily: "Merriweather, serif" }}
                >
                  📝 Formulário de Intenção de Missa
                </h3>
              </div>
              <div className="p-6 bg-white">
                <p className="text-gray-600 mb-4 text-sm">
                  Preencha o formulário abaixo com seus dados e sua intenção. Você será contactado para confirmar a data e horário da missa.
                </p>
                
                {/* Google Forms Embed */}
                <div
                  style={{
                    width: "100%",
                    minHeight: "800px",
                    border: "1px solid #dbeafe",
                    borderRadius: "8px",
                    overflow: "hidden",
                  }}
                >
                  <iframe
                    title="Formulário de Intenção de Missa"
                    src="https://docs.google.com/forms/d/e/1FAIpQLSfKz8Ky3-8e8Ky3-8e8Ky3-8e8Ky3-8e8Ky3-8e8Ky3-8e8Ky3-8e8/viewform?embedded=true"
                    width="100%"
                    height="800"
                    frameBorder="0"
                    marginHeight={0}
                    marginWidth={0}
                    style={{ display: "block" }}
                  >
                    Carregando…
                  </iframe>
                </div>

                <div className="mt-6 p-4 rounded-lg" style={{ background: "#f0f7ff" }}>
                  <p className="text-sm text-gray-600">
                    <strong>Nota:</strong> Se o formulário não aparecer, você pode entrar em contato conosco diretamente pelo telefone 
                    <a href="tel:+556134438909" className="font-semibold ml-1 hover:underline" style={{ color: "#2563eb" }}>
                      (61) 3443-8909
                    </a> ou 
                    <a href="https://wa.me/556134438909" target="_blank" rel="noopener noreferrer" className="font-semibold ml-1 hover:underline" style={{ color: "#25D366" }}>
                      WhatsApp
                    </a>.
                  </p>
                </div>
              </div>
            </div>

            {/* Informações adicionais */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Horários */}
              <div
                className="rounded-xl p-6"
                style={{ background: "#dbeafe" }}
              >
                <h4
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  <span className="text-xl">⏰</span> Horários de Missa
                </h4>
                <table className="w-full text-sm">
                  <tbody>
                    <tr className="border-b border-blue-200">
                      <td className="py-2 font-medium text-gray-700 pr-4">Segunda a Sábado</td>
                      <td className="py-2 font-bold" style={{ color: "#1e3a5f" }}>7h30 e 19h</td>
                    </tr>
                    <tr>
                      <td className="py-2 font-medium text-gray-700 pr-4">Domingo</td>
                      <td className="py-2 font-bold" style={{ color: "#1e3a5f" }}>10h e 19h</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Contato */}
              <div
                className="rounded-xl p-6"
                style={{ background: "#dbeafe" }}
              >
                <h4
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ fontFamily: "Merriweather, serif", color: "#1e3a5f" }}
                >
                  <span className="text-xl">📞</span> Dúvidas?
                </h4>
                <p className="text-gray-600 text-sm mb-3">
                  Entre em contato com a secretaria paroquial:
                </p>
                <div className="space-y-2">
                  <a
                    href="tel:+556134438909"
                    className="block text-sm font-semibold hover:underline"
                    style={{ color: "#2563eb" }}
                  >
                    📱 (61) 3443-8909
                  </a>
                  <a
                    href="https://wa.me/556134438909"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-sm font-semibold hover:underline"
                    style={{ color: "#25D366" }}
                  >
                    💬 WhatsApp
                  </a>
                  <a
                    href="mailto:secretaria.santissimo@gmail.com"
                    className="block text-sm font-semibold hover:underline"
                    style={{ color: "#2563eb" }}
                  >
                    ✉️ secretaria.santissimo@gmail.com
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-12 bg-white">
        <div className="container">
          <div
            className="max-w-2xl mx-auto rounded-2xl p-8 text-center"
            style={{ background: "#1e3a5f" }}
          >
            <h3
              className="text-white font-bold text-xl mb-3"
              style={{ fontFamily: "Merriweather, serif" }}
            >
              Outras Formas de Participar
            </h3>
            <p className="text-blue-200 mb-5 text-sm">
              Conheça outras maneiras de se envolver com a comunidade paroquial.
            </p>
            <div className="flex flex-wrap gap-3 justify-center">
              <Link
                href="/sobre"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all duration-200 hover:opacity-90"
                style={{ background: "#d4a017", color: "#1e3a5f" }}
              >
                Conheça nossa história
              </Link>
              <Link
                href="/contato"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all duration-200 hover:opacity-90"
                style={{ background: "rgba(255,255,255,0.15)", color: "white", border: "1px solid rgba(255,255,255,0.3)" }}
              >
                Fale conosco
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
