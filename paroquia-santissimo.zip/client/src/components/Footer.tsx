/**
 * Footer — Paróquia Santíssimo Sacramento
 * Design: Herança Viva — fundo azul profundo, links brancos
 */
import { Link } from "wouter";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Footer() {
  return (
    <footer style={{ background: "#1e3a5f" }} className="text-white">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Coluna 1 — Identidade */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none">
                  <circle cx="12" cy="12" r="4" fill="#d4a017" />
                  <circle cx="12" cy="12" r="2.5" fill="white" />
                  {[0,30,60,90,120,150,180,210,240,270,300,330].map((deg, i) => (
                    <line
                      key={i}
                      x1="12" y1="12"
                      x2={12 + 8 * Math.cos((deg * Math.PI) / 180)}
                      y2={12 + 8 * Math.sin((deg * Math.PI) / 180)}
                      stroke="#d4a017"
                      strokeWidth="1.2"
                      strokeLinecap="round"
                    />
                  ))}
                </svg>
              </div>
              <div>
                <p className="font-bold text-white leading-tight" style={{ fontFamily: "Merriweather, serif" }}>
                  Santíssimo Sacramento
                </p>
                <p className="text-blue-200 text-xs">Santuário Arquidiocesano</p>
              </div>
            </div>
            <p className="text-blue-200 text-sm leading-relaxed">
              Santuário Arquidiocesano da Adoração Perpétua a Jesus Cristo no Santíssimo Sacramento da Eucaristia, em Brasília — DF.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" stroke="white" strokeWidth="2" fill="none"/>
                  <circle cx="12" cy="12" r="4" stroke="white" strokeWidth="2" fill="none"/>
                  <circle cx="17.5" cy="6.5" r="1.2" fill="white"/>
                </svg>
              </a>
              <a href="https://wa.me/556134438909" target="_blank" rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Coluna 2 — Links rápidos */}
          <div>
            <h3 className="font-bold text-white mb-4 text-sm uppercase tracking-wider" style={{ fontFamily: "Merriweather, serif" }}>
              Navegação
            </h3>
            <ul className="space-y-2">
              {[
                { href: "/", label: "Início" },
                { href: "/sobre", label: "Sobre a Paróquia" },
                { href: "/localizacao", label: "Localização" },
                { href: "/contato", label: "Contate-nos" },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-blue-200 hover:text-white text-sm transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Coluna 3 — Contato */}
          <div>
            <h3 className="font-bold text-white mb-4 text-sm uppercase tracking-wider" style={{ fontFamily: "Merriweather, serif" }}>
              Contato
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-blue-300 flex-shrink-0 mt-0.5" />
                <span className="text-blue-200 text-sm">SGAS 606 Lotes 41/42 — L2 Sul, Asa Sul, 70.200-660, Brasília — DF</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-300 flex-shrink-0" />
                <a href="tel:+556134438909" className="text-blue-200 hover:text-white text-sm transition-colors">(61) 3443-8909</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-300 flex-shrink-0" />
                <a href="mailto:secretaria.santissimo@gmail.com" className="text-blue-200 hover:text-white text-sm transition-colors">
                  secretaria.santissimo@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-blue-300 flex-shrink-0 mt-0.5" />
                <span className="text-blue-200 text-sm">Seg–Sex: 8h–12h e 13h–17h30 | Sáb: 8h–12h</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
        <div className="container py-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <p className="text-blue-300 text-xs">
            © {new Date().getFullYear()} Paróquia Santíssimo Sacramento — Brasília, DF
          </p>
          <p className="text-blue-400 text-xs">
            Santuário Arquidiocesano da Adoração Perpétua
          </p>
        </div>
      </div>
    </footer>
  );
}
