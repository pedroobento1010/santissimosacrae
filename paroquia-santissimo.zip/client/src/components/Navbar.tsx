/**
 * Navbar — Paróquia Santíssimo Sacramento
 * Design: Herança Viva — fundo azul profundo (#1e3a5f), links brancos, ícone de casa centralizado
 * Rotas: Home (ícone), Sobre, Intenções de Missa, Localização, Contate-nos
 */
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Home } from "lucide-react";

const NAV_LINKS = [
  { href: "/sobre", label: "Sobre" },
  { href: "/intencoes", label: "Intenções de Missa" },
  { href: "/localizacao", label: "Localização" },
  { href: "/contato", label: "Contate-nos" },
];

export default function Navbar() {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled
          ? "rgba(30, 58, 95, 0.97)"
          : "#1e3a5f",
        backdropFilter: scrolled ? "blur(8px)" : "none",
        boxShadow: scrolled ? "0 2px 20px rgba(0,0,0,0.25)" : "none",
      }}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-18">
          {/* Logo / Brand */}
          <Link href="/" className="flex items-center gap-3 group">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(255,255,255,0.15)" }}
            >
              {/* Ostensório SVG simples */}
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
                <circle cx="12" cy="12" r="4" fill="#d4a017" />
                <circle cx="12" cy="12" r="2.5" fill="white" />
                {[0,30,60,90,120,150,180,210,240,270,300,330].map((deg, i) => (
                  <line
                    key={i}
                    x1="12" y1="12"
                    x2={12 + 8 * Math.cos((deg * Math.PI) / 180)}
                    y2={12 + 8 * Math.sin((deg * Math.PI) / 180)}
                    stroke="#d4a017"
                    strokeWidth="1.2"
                    strokeLinecap="round"
                  />
                ))}
              </svg>
            </div>
            <div className="leading-tight">
              <span
                className="block text-white font-bold text-sm md:text-base leading-tight"
                style={{ fontFamily: "Merriweather, serif" }}
              >
                Santíssimo Sacramento
              </span>
              <span className="block text-blue-200 text-xs leading-tight">
                Santuário Arquidiocesano
              </span>
            </div>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-3">
            {/* Home Icon - Centered */}
            <Link
              href="/"
              className="flex items-center justify-center w-9 h-9 rounded-lg transition-all duration-200 hover:bg-white/15"
              title="Início"
            >
              <Home className={`w-5 h-5 ${location === "/" ? "text-yellow-400" : "text-white"}`} />
            </Link>

            {/* Divider */}
            <div style={{ width: "1px", height: "24px", background: "rgba(255,255,255,0.2)" }} />

            {/* Other links */}
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`nav-link ${location === link.href ? "active" : ""}`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Social icons + mobile toggle */}
          <div className="flex items-center gap-2">
            {/* Instagram */}
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              title="Instagram"
              className="w-8 h-8 flex items-center justify-center rounded-full transition-all duration-200 hover:bg-white/20"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" stroke="white" strokeWidth="2" fill="none"/>
                <circle cx="12" cy="12" r="4" stroke="white" strokeWidth="2" fill="none"/>
                <circle cx="17.5" cy="6.5" r="1.2" fill="white"/>
              </svg>
            </a>
            {/* WhatsApp */}
            <a
              href="https://wa.me/556134438909"
              target="_blank"
              rel="noopener noreferrer"
              title="WhatsApp"
              className="w-8 h-8 flex items-center justify-center rounded-full transition-all duration-200 hover:bg-white/20"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </a>
            {/* Facebook */}
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              title="Facebook"
              className="w-8 h-8 flex items-center justify-center rounded-full transition-all duration-200 hover:bg-white/20"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
            </a>

            {/* Mobile toggle */}
            <button
              className="md:hidden w-8 h-8 flex items-center justify-center text-white rounded ml-1"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div
          className="md:hidden border-t"
          style={{ borderColor: "rgba(255,255,255,0.15)", background: "#1e3a5f" }}
        >
          <div className="container py-3 flex flex-col gap-1">
            {/* Home Icon Mobile */}
            <Link
              href="/"
              className="nav-link block py-2 flex items-center gap-2"
              onClick={() => setMobileOpen(false)}
            >
              <Home className="w-4 h-4" /> Início
            </Link>

            {/* Other links */}
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`nav-link block py-2 ${location === link.href ? "active" : ""}`}
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
